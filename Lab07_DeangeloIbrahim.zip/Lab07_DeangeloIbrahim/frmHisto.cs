﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Histo;

namespace Lab07_DeangeloIbrahim
{
    public partial class frmHisto : Form
    {

        
        string[] DictWords = new string[100];
        int NumDict;
        int NumPal;
        string[] PalWords = new string[100];

        
        public frmHisto()
        {
            InitializeComponent();
        }

        private void Histo_Load(object sender, EventArgs e)
        {
            StreamReader DFile; // Stores words from dict.txt into Dictwords
            DFile = File.OpenText("dict.txt");

            int i = 0;
            while (!DFile.EndOfStream)
            {
                string data;
                data = DFile.ReadLine();
                DictWords[i] = data;
                i++;
            }

            NumDict = i;

            DFile.Close();
           // Dict.txt ^^


            //Pal.txt
            StreamReader PFile;
            PFile = File.OpenText("pal.txt");

            i = 0;
            while (!PFile.EndOfStream) //stores words in PalWords
            {
                string data;
                data = PFile.ReadLine();
                PalWords[i] = data;
                i++;
            }

            NumPal = i;
            PFile.Close();

        }

        private void btnLA_Click(object sender, EventArgs e)
        {

            //creating anagrams
            string WordTest;
            string ComparedWord;
            int[] DictLetters = new int[26];
            int[] PalLetters = new int[26];


           
            for (int i = 0; i < NumDict; i++)
            {
                WordTest = DictWords[i];
                Histo.Histogram.CreateHistogram(DictLetters, WordTest);

                for (int j = 0; j < NumPal; j++)
                {
                    ComparedWord = PalWords[j];
                    Histo.Histogram.CreateHistogram(PalLetters, ComparedWord); //calls histogram

                    int cnt = 0;
                    int t;
                    for (t = 0; t < 26; t++)
                    {
                        if (DictLetters[t] == PalLetters[t]) //compares words letter by letter
                        {
                            cnt++;
                        }

                  
                    }
                    if (cnt == 26)
                    {
                        lbAnagrams.Items.Add(WordTest + " ----->" + ComparedWord);
                   

                        
                    }

                }

            }

        

        }
    }
}
