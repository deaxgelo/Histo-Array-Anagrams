﻿namespace Lab07_DeangeloIbrahim
{
    partial class frmHisto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbAnagrams = new System.Windows.Forms.ListBox();
            this.btnLA = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbAnagrams
            // 
            this.lbAnagrams.Font = new System.Drawing.Font("Perpetua", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAnagrams.FormattingEnabled = true;
            this.lbAnagrams.ItemHeight = 22;
            this.lbAnagrams.Location = new System.Drawing.Point(44, 26);
            this.lbAnagrams.Name = "lbAnagrams";
            this.lbAnagrams.Size = new System.Drawing.Size(707, 268);
            this.lbAnagrams.TabIndex = 0;
            // 
            // btnLA
            // 
            this.btnLA.Font = new System.Drawing.Font("Perpetua", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLA.Location = new System.Drawing.Point(79, 344);
            this.btnLA.Name = "btnLA";
            this.btnLA.Size = new System.Drawing.Size(171, 52);
            this.btnLA.TabIndex = 1;
            this.btnLA.Text = "List Anagrams";
            this.btnLA.UseVisualStyleBackColor = true;
            this.btnLA.Click += new System.EventHandler(this.btnLA_Click);
            // 
            // Histo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLA);
            this.Controls.Add(this.lbAnagrams);
            this.Name = "Histo";
            this.Text = "Histo";
            this.Load += new System.EventHandler(this.Histo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbAnagrams;
        private System.Windows.Forms.Button btnLA;
    }
}

